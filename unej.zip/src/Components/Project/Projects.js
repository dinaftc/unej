import React from 'react'
import { Project } from './Project';
import p1 from'./p.png'

export default function Projects() {
    const projects=[
        {image:p1,
        title:'les modalités d’instruction et de délivrance des actes d’urbanisme',
        description:'Contrary to popular belief, Lore Ipsum is not simply random text. It has roots in a piece...en savoir plus',

    },
    {image:p1,
        title:'les modalités d’instruction et de délivrance des actes d’urbanisme',
        description:'Contrary to popular belief, Lore Ipsum is not simply random text. It has roots in a piece...en savoir plus',

    },{image:p1,
        title:'les modalités d’instruction et de délivrance des actes d’urbanisme',
        description:'Contrary to popular belief, Lore Ipsum is not simply random text. It has roots in a piece...en savoir plus',

    },{image:p1,
        title:'les modalités d’instruction et de délivrance des actes d’urbanisme',
        description:'Contrary to popular belief, Lore Ipsum is not simply random text. It has roots in a piece...en savoir plus',

    },{image:p1,
        title:'les modalités d’instruction et de délivrance des actes d’urbanisme',
        description:'Contrary to popular belief, Lore Ipsum is not simply random text. It has roots in a piece...en savoir plus',

    },
        ]
  return (
    <div className='pb-10' id='Projects'>
        <div className='mb-2'>
            <h1 className=' text-center text-4xl font-bold p-6'>Articles</h1>
        </div>
<div className='grid grid-cols-1 lg:grid-cols-1 gap-10 pt-3 pb-10 ml-5'>
    {projects.map ((project,i) => (<Project key={i} project={project}></Project>)
    )}
</div>
    </div>
  )
}